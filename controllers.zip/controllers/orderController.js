const {
  Order,
  OrderItem,
  Menu,
  Payment,
  User,
  UserCoupon,
  Coupon,
  Table,
  sequelize,
} = require('../models');
const { Op } = require('sequelize');

const validateTableNumber = async (req, res) => {
  try {
    const { tableNumber } = req.params;

    if (!tableNumber || isNaN(tableNumber)) {
      return res.status(400).json({
        success: false,
        message: 'Nomor meja tidak valid',
      });
    }

    const tableNum = parseInt(tableNumber);

    // Cari table berdasarkan table_number
    const table = await Table.findOne({
      where: { 
        table_number: tableNum,
        is_active: true 
      }
    });

    if (!table) {
      return res.status(404).json({
        success: false,
        message: `Meja #${tableNum} tidak ditemukan atau tidak aktif`,
      });
    }

    res.json({
      success: true,
      message: 'Meja valid',
      data: {
        table_id: table.id,
        table_number: table.table_number,
        qr_code_url: table.qr_code_url,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Terjadi kesalahan saat memvalidasi meja',
      error: process.env.NODE_ENV === 'development' ? error.message : null,
    });
  }
};

const createOrder = async (req, res) => {
  const { table_number, items, notes, user_coupon_id } = req.body;

  console.log('🆕 CREATE ORDER - Request data:', {
    table_number,
    user_coupon_id,
    user: req.user?.id,
    items_count: items?.length,
  });

  if (!items?.length) {
    return res.status(400).json({
      success: false,
      message: 'Items are required',
    });
  }

  // FIX: Cari table berdasarkan table_number yang dikirim frontend
  let table = null;
  let table_id = null;

  if (table_number) {
    table = await Table.findOne({
      where: {
        table_number: table_number, // ← CARI BERDASARKAN table_number
        is_active: true,
      },
    });

    if (!table) {
      return res.status(400).json({
        success: false,
        message: `Nomor meja ${table_number} tidak valid atau tidak aktif`,
      });
    }
    table_id = table.id; // ← DAPATKAN table_id DARI TABLE YANG DITEMUKAN
    console.log('✅ Table found:', {
      table_id,
      table_number: table.table_number,
    });
  }

  const type = table_number ? 'dine-in' : 'take-away';
  const transaction = await sequelize.transaction();

  try {
    // Hitung total harga
    const menus = await Menu.findAll({
      where: { id: items.map((i) => i.menu_id) },
      transaction,
    });

    let total_price = menus.reduce((sum, menu) => {
      const item = items.find((i) => i.menu_id === menu.id);
      return sum + menu.price * item.quantity;
    }, 0);

    console.log('💰 Total price calculation:', total_price);

    // VARIABLES UNTUK COUPON & DISCOUNT
    let discount_amount = 0;
    let coupon_used = null;
    let final_price = total_price;
    let user_coupon = null;

    // PROSES COUPON JIKA ADA (hanya untuk user login)
    if (user_coupon_id && req.user?.id) {
      console.log('🔍 LOOKING FOR COUPON:', {
        user_coupon_id,
        user_id: req.user.id,
      });

      try {
        user_coupon = await UserCoupon.findOne({
          where: {
            id: user_coupon_id,
            user_id: req.user.id,
            is_used: false,
          },
          include: [
            {
              model: Coupon,
              as: 'coupon',
              where: {
                is_active: true,
                [Op.or]: [
                  { valid_until: null },
                  { valid_until: { [Op.gt]: new Date() } },
                ],
              },
            },
          ],
          transaction,
        });

        console.log('📦 COUPON QUERY RESULT:', {
          found: !!user_coupon,
          user_coupon_id: user_coupon?.id,
          is_used: user_coupon?.is_used,
          has_coupon: !!user_coupon?.coupon,
          coupon_name: user_coupon?.coupon?.name,
        });

        if (user_coupon && user_coupon.coupon) {
          const coupon = user_coupon.coupon;

          console.log('🎯 COUPON VALIDATION:', {
            coupon_id: coupon.id,
            coupon_name: coupon.name,
            max_usage: coupon.max_usage,
            current_usage: coupon.current_usage,
            can_use:
              !coupon.max_usage || coupon.current_usage < coupon.max_usage,
          });

          // Validasi tambahan
          if (coupon.max_usage && coupon.current_usage >= coupon.max_usage) {
            console.log('❌ COUPON USAGE LIMIT REACHED');
            await transaction.rollback();
            return res.status(400).json({
              success: false,
              message: 'Kupon sudah mencapai batas penggunaan',
            });
          }

          // Hitung discount berdasarkan type
          if (coupon.discount_type === 'percentage') {
            discount_amount = Math.floor(
              total_price * (coupon.discount_value / 100)
            );
          } else if (coupon.discount_type === 'fixed') {
            discount_amount = Math.min(coupon.discount_value, total_price);
          }

          console.log('💸 DISCOUNT CALCULATION:', {
            discount_type: coupon.discount_type,
            discount_value: coupon.discount_value,
            discount_amount: discount_amount,
          });

          // Apply discount
          final_price = Math.max(0, total_price - discount_amount);

          console.log('💳 FINAL PRICE:', {
            original: total_price,
            discount: discount_amount,
            final: final_price,
          });

          // Update coupon usage count
          console.log('🔄 UPDATING COUPON USAGE COUNT');
          await Coupon.increment('current_usage', {
            by: 1,
            where: { id: coupon.id },
            transaction,
          });

          // Mark user coupon as used
          console.log('🔄 MARKING USER COUPON AS USED');
          const [affectedRows] = await UserCoupon.update(
            {
              is_used: true,
              used_at: new Date(),
            },
            {
              where: {
                id: user_coupon.id,
                is_used: false,
              },
              transaction,
            }
          );

          console.log('✅ USER COUPON UPDATE RESULT:', { affectedRows });

          if (affectedRows === 0) {
            await transaction.rollback();
            return res.status(400).json({
              success: false,
              message: 'Kupon sudah digunakan oleh proses lain',
            });
          }

          coupon_used = {
            coupon_id: coupon.id,
            coupon_name: coupon.name,
            discount_type: coupon.discount_type,
            discount_value: coupon.discount_value,
            discount_amount: discount_amount,
            user_coupon_id: user_coupon.id,
          };

          console.log('🎉 COUPON SUCCESSFULLY APPLIED:', coupon_used);
        } else {
          console.log('⚠️ COUPON NOT FOUND OR ALREADY USED');
        }
      } catch (couponError) {
        console.error('❌ COUPON PROCESSING ERROR:', couponError);
        // Continue without coupon if there's an error
      }
    } else {
      console.log(
        '⏩ SKIPPING COUPON PROCESSING - No user_coupon_id or user not logged in'
      );
    }

    // Buat order dengan table_id
    console.log('📝 CREATING ORDER WITH DATA:', {
      table_id,
      type,
      total_price: final_price,
      original_price: total_price,
      discount_amount: discount_amount,
      user_id: req.user?.id || null,
      has_coupon: !!coupon_used,
    });

    const order = await Order.create(
      {
        table_id: table_id, 
        type,
        status: 'pending',
        payment_type: 'cash',
        is_paid: false,
        total_price: final_price,
        original_price: total_price,
        discount_amount: discount_amount,
        user_id: req.user?.id || null,
        notes: notes || null,
        coupon_used: coupon_used ? JSON.stringify(coupon_used) : null,
        points_awarded: false,
        points_earned: 0,
      },
      { transaction }
    );

    console.log('✅ ORDER CREATED:', {
      id: order.id,
      total_price: order.total_price,
      table_id: order.table_id,
    });

    // Buat order items
    await OrderItem.bulkCreate(
      items.map((item) => ({
        order_id: order.id,
        menu_id: item.menu_id,
        quantity: item.quantity,
        subtotal:
          menus.find((m) => m.id === item.menu_id).price * item.quantity,
      })),
      { transaction }
    );

    // Buat payment record
    await Payment.create(
      {
        order_id: order.id,
        amount: final_price,
        status: 'pending',
      },
      { transaction }
    );

    await transaction.commit();

    console.log('🎊 ORDER COMPLETED SUCCESSFULLY');

    return res.json({
      success: true,
      orderId: order.id,
      message: coupon_used
        ? 'Order berhasil dibuat dengan kupon'
        : 'Order created successfully',
      data: {
        order_id: order.id,
        table_number: table_number,
        total_price: final_price,
        original_price: total_price,
        discount_amount: discount_amount,
        coupon_used: coupon_used,
        points_earned: 0,
      },
    });
  } catch (error) {
    await transaction.rollback();
    console.error('❌ ORDER CREATION ERROR:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create order',
      error: process.env.NODE_ENV === 'development' ? error.message : null,
    });
  }
};

const createOrderGuest = async (req, res) => {
  const {
    table_number,
    items,
    notes,
    payment_type,
    service_type,
    totalAmount,
  } = req.body;

  console.log('🆕 CREATE ORDER GUEST - Request data:', {
    table_number,
    items_count: items?.length,
    service_type,
    payment_type,
    totalAmount,
  });

  if (!items?.length) {
    return res.status(400).json({
      success: false,
      message: 'Items are required',
    });
  }

  let table = null;
  let table_id = null;

  // 🪑 Cari table_id berdasarkan table_number
  if (table_number) {
    table = await Table.findOne({
      where: { table_number, is_active: true },
    });

    if (!table) {
      return res.status(400).json({
        success: false,
        message: `Nomor meja ${table_number} tidak valid atau tidak aktif`,
      });
    }

    table_id = table.id;
    console.log('✅ Table found:', {
      table_id,
      table_number: table.table_number,
    });
  }

  // Tentukan type order
  const type = table_number ? 'dine-in' : 'take-away';
  const transaction = await sequelize.transaction();

  try {
    // 🔹 Ambil harga menu
    const menus = await Menu.findAll({
      where: { id: items.map((i) => i.menu_id) },
      transaction,
    });

    // 🔹 Hitung total harga
    const total_price = menus.reduce((sum, menu) => {
      const item = items.find((i) => i.menu_id === menu.id);
      return sum + menu.price * item.quantity;
    }, 0);

    console.log('💰 Total price calculation:', total_price);

    // 🔹 Buat order utama
    const order = await Order.create(
      {
        table_id,
        type, // <-- simpan dine-in / take-away ke kolom "type"
        status: 'pending',
        payment_type: payment_type || 'cash',
        is_paid: false,
        total_price,
        original_price: total_price,
        discount_amount: 0,
        user_id: null,
        notes: notes || null,
        coupon_used: null,
        points_awarded: false,
        points_earned: 0,
      },
      { transaction }
    );

    console.log('✅ ORDER CREATED:', {
      id: order.id,
      table_id: order.table_id,
    });

    // 🔹 Buat order items
    await OrderItem.bulkCreate(
      items.map((item) => ({
        order_id: order.id,
        menu_id: item.menu_id,
        quantity: item.quantity,
        subtotal:
          menus.find((m) => m.id === item.menu_id).price * item.quantity,
      })),
      { transaction }
    );

    // 🔹 Buat payment record
    await Payment.create(
      {
        order_id: order.id,
        amount: total_price,
        status: 'pending',
      },
      { transaction }
    );

    await transaction.commit();

    console.log('🎉 GUEST ORDER SUCCESSFULLY CREATED');

    return res.json({
      success: true,
      orderId: order.id,
      message: 'Guest order created successfully',
      data: {
        order_id: order.id,
        table_number,
        total_price,
        type,
      },
    });
  } catch (error) {
    await transaction.rollback();
    console.error('❌ CREATE ORDER GUEST ERROR:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to create guest order',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined,
    });
  }
};

// GET ALL ORDERS - WITH USER & TABLE DATA
const getAllOrders = async (req, res) => {
  const { page = 1, limit = 12 } = req.query;
  const offset = (page - 1) * limit;

  try {
    const { count, rows: orders } = await Order.findAndCountAll({
      include: [
        {
          model: OrderItem,
          as: 'items',
          include: {
            model: Menu,
            attributes: ['name', 'price'],
          },
        },
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone_number', 'role_id'],
          required: false,
        },
        {
          model: Table,
          as: 'table',
          attributes: ['table_number', 'is_active'],
          required: false,
        },
      ],
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
      distinct: true,
    });

    res.status(200).json({
      success: true,
      message: 'Berhasil mengambil data pesanan',
      data: orders,
      pagination: {
        total: count,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(count / limit),
      },
    });
  } catch (err) {
    console.error('❌ [ORDER CONTROLLER] Error:', err);
    res.status(500).json({
      success: false,
      message: 'Gagal mengambil data pesanan',
    });
  }
};

// GET ORDER BY ID - WITH USER & TABLE DATA
const getOrderById = async (req, res) => {
  const { id } = req.params;

  try {
    const order = await Order.findOne({
      where: { id },
      include: [
        {
          model: OrderItem,
          as: 'items',
          include: {
            model: Menu,
            attributes: ['id', 'name', 'price', 'imageUrl'],
          },
        },
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone_number', 'role_id'],
          required: false,
        },
        {
          model: Table,
          as: 'table',
          attributes: ['table_number', 'is_active'],
          required: false,
        },
      ],
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found',
      });
    }

    // Parse coupon_used jika ada
    const orderData = order.toJSON();
    if (orderData.coupon_used) {
      orderData.coupon_used = JSON.parse(orderData.coupon_used);
    }

    res.status(200).json({
      success: true,
      data: orderData,
    });
  } catch (err) {
    console.error('Error fetching order:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch order details',
    });
  }
};

// GET PUBLIC ORDER BY ID (UNTUK GUEST)
const getPublicOrderById = async (req, res) => {
  const { id } = req.params;

  try {
    const order = await Order.findOne({
      where: { id },
      attributes: [
        'id',
        'status',
        'type',
        'payment_type',
        'is_paid',
        'total_price',
        'original_price',
        'discount_amount',
        'notes',
        'createdAt',
      ],
      include: [
        {
          model: OrderItem,
          as: 'items',
          attributes: ['id', 'quantity', 'subtotal'],
          include: {
            model: Menu,
            attributes: ['id', 'name', 'price', 'imageUrl'],
          },
        },
        {
          model: Table,
          as: 'table',
          attributes: ['table_number'],
          required: false,
        },
      ],
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found',
      });
    }

    res.json({
      success: true,
      data: order,
    });
  } catch (err) {
    console.error('Error in getPublicOrderById:', err);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: err.message,
    });
  }
};

// FUNCTION: Add points to user after order completion
const addPointsAfterOrderCompletion = async (orderId) => {
  console.log(`🔄 [POINTS] Attempting to add points for order ${orderId}`);
  const transaction = await sequelize.transaction();

  try {
    const order = await Order.findByPk(orderId, { transaction });

    console.log(`📦 [POINTS] Order details:`, {
      id: order?.id,
      status: order?.status,
      is_paid: order?.is_paid,
      user_id: order?.user_id,
      total_price: order?.total_price,
      points_awarded: order?.points_awarded,
      points_earned: order?.points_earned,
    });

    // Validasi conditions untuk beri poin
    if (!order) {
      console.log('❌ [POINTS] Order not found');
      await transaction.rollback();
      return;
    }

    if (order.status !== 'done') {
      console.log(`❌ [POINTS] Order status is ${order.status}, need 'done'`);
      await transaction.rollback();
      return;
    }

    if (!order.is_paid) {
      console.log('❌ [POINTS] Order is not paid');
      await transaction.rollback();
      return;
    }

    if (!order.user_id) {
      console.log('❌ [POINTS] No user_id (guest order)');
      await transaction.rollback();
      return;
    }

    if (order.points_awarded) {
      console.log('⚠️ [POINTS] Points already awarded');
      await transaction.rollback();
      return;
    }

    // Hitung poin (1 poin = Rp 10.000)
    const points_earned = Math.floor(order.total_price / 10000);
    console.log(
      `💰 [POINTS] Calculation: ${order.total_price} / 10000 = ${points_earned} points`
    );

    if (points_earned > 0) {
      const user = await User.findByPk(order.user_id, { transaction });
      console.log(`👤 [POINTS] User found:`, {
        id: user?.id,
        name: user?.name,
        current_points: user?.points,
      });

      if (!user) {
        console.log('❌ [POINTS] User not found');
        await transaction.rollback();
        return;
      }

      // Update user points
      const newPoints = user.points + points_earned;
      user.points = newPoints;
      await user.save({ transaction });
      console.log(
        `✅ [POINTS] User points updated: ${user.points} → ${newPoints}`
      );

      // Mark order sebagai sudah dapat poin
      order.points_awarded = true;
      order.points_earned = points_earned;
      await order.save({ transaction });
      console.log(
        `🎯 [POINTS] Order marked as points awarded: ${points_earned} points`
      );
    } else {
      console.log('ℹ️ [POINTS] No points earned (total price too low)');
    }

    await transaction.commit();
    console.log(
      `🎉 [POINTS] SUCCESS: Added ${points_earned} points to user ${order.user_id}`
    );
  } catch (error) {
    await transaction.rollback();
    console.error('❌ [POINTS] Error:', error);
  }
};

// UPDATE ORDER STATUS - WITH POINTS AWARD
const updateOrderStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  console.log(`🔄 [STATUS] Updating order ${id} to status: ${status}`);

  try {
    const order = await Order.findByPk(id, {
      include: [
        {
          model: OrderItem,
          as: 'items',
          include: {
            model: Menu,
            attributes: ['id', 'name', 'price', 'imageUrl'],
          },
        },
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone_number', 'role_id'],
          required: false,
        },
        {
          model: Table,
          as: 'table',
          attributes: ['table_number'],
          required: false,
        },
      ],
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found',
      });
    }

    // Validasi transisi status
    const validTransitions = {
      pending: ['processing'],
      processing: ['done'],
      done: [],
    };

    if (!validTransitions[order.status]?.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status transition from ${order.status} to ${status}`,
      });
    }

    const oldStatus = order.status;
    order.status = status;
    await order.save();

    console.log(`✅ [STATUS] Order status updated to: ${status}`);

    // REAL-TIME UPDATE dengan safety check
    try {
      if (global.io) {
        const orderData = order.toJSON();

        // Parse coupon_used jika ada
        if (orderData.coupon_used) {
          try {
            orderData.coupon_used = JSON.parse(orderData.coupon_used);
          } catch (e) {
            console.log('❌ Error parsing coupon_used:', e);
          }
        }

        // Emit ke admin room
        global.io.to('admin-room').emit('order-status-updated', {
          orderId: id,
          oldStatus: oldStatus,
          newStatus: status,
          order: orderData,
          timestamp: new Date().toISOString(),
        });

        // Emit ke customer room (order specific)
        global.io.to(`order-${id}`).emit('order-status-changed', {
          orderId: id,
          oldStatus: oldStatus,
          newStatus: status,
          order: orderData,
          message: `Status pesanan berubah dari ${oldStatus} menjadi ${status}`,
          timestamp: new Date().toISOString(),
        });

        console.log(`📢 [REAL-TIME] Emitted status update for order ${id}`);
      } else {
        console.log(
          '⚠️ [REAL-TIME] io not available, skipping real-time update'
        );
      }
    } catch (wsError) {
      console.error('❌ [REAL-TIME] WebSocket error:', wsError);
      // Jangan gagalkan request hanya karena WebSocket error
    }

    // JIKA ORDER SELESAI & SUDAH BAYAR, BERI POIN
    if (status === 'done' && order.is_paid && order.user_id) {
      console.log(`🎯 [STATUS] Triggering points award for order ${id}`);
      addPointsAfterOrderCompletion(order.id);
    }

    res.json({
      success: true,
      data: order,
      message: `Status order berhasil diupdate dari ${oldStatus} menjadi ${status}`,
      realTimeUpdate: !!global.io, // Info apakah real-time berhasil
    });
  } catch (err) {
    console.error('❌ [STATUS] Error:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to update status',
    });
  }
};

// CONFIRM CASH PAYMENT - WITH POINTS AWARD
const confirmCashPayment = async (req, res) => {
  const { id } = req.params;
  const transaction = await sequelize.transaction();

  console.log(`💵 [PAYMENT] Confirming cash payment for order ${id}`);

  try {
    const order = await Order.findByPk(id, {
      include: [
        {
          model: OrderItem,
          as: 'items',
          include: {
            model: Menu,
            attributes: ['id', 'name', 'price', 'imageUrl'],
          },
        },
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone_number', 'role_id'],
          required: false,
        },
        {
          model: Table,
          as: 'table',
          attributes: ['table_number'],
          required: false,
        },
      ],
      transaction,
    });

    if (!order) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'Order not found',
      });
    }

    console.log(`📊 [PAYMENT] Order before confirmation:`, {
      status: order.status,
      is_paid: order.is_paid,
      user_id: order.user_id,
    });

    if (order.payment_type !== 'cash') {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'Only cash payments can be confirmed',
      });
    }

    // Update order
    order.is_paid = true;
    await order.save({ transaction });

    // Update or create payment
    const payment = await Payment.findOne({
      where: { order_id: id },
      transaction,
    });

    if (payment) {
      payment.status = 'completed';
      payment.paid_at = new Date();
      await payment.save({ transaction });
    } else {
      await Payment.create(
        {
          order_id: id,
          amount: order.total_price,
          status: 'completed',
          paid_at: new Date(),
          payment_type: 'cash',
        },
        { transaction }
      );
    }

    await transaction.commit();

    console.log(`✅ [PAYMENT] Payment confirmed successfully`);

    // REAL-TIME UPDATE: Kirim update pembayaran ke admin dan customer
    try {
      if (global.io) {
        const orderData = order.toJSON();

        // Parse coupon_used jika ada
        if (orderData.coupon_used) {
          try {
            orderData.coupon_used = JSON.parse(orderData.coupon_used);
          } catch (e) {
            console.log('❌ Error parsing coupon_used:', e);
          }
        }

        // Emit ke admin room
        global.io.to('admin-room').emit('payment-confirmed', {
          orderId: id,
          is_paid: true,
          order: orderData,
          payment: payment ? payment.toJSON() : null,
          timestamp: new Date().toISOString(),
          message: `Pembayaran untuk order #${id} telah dikonfirmasi`,
        });

        // Emit ke customer room
        global.io.to(`order-${id}`).emit('payment-status-changed', {
          orderId: id,
          is_paid: true,
          order: orderData,
          message: `Pembayaran telah dikonfirmasi - Status: LUNAS`,
          timestamp: new Date().toISOString(),
        });

        console.log(
          `📢 [REAL-TIME] Emitted payment confirmation for order ${id}`
        );
      } else {
        console.log('⚠️ [REAL-TIME] io not available for payment update');
      }
    } catch (wsError) {
      console.error('❌ [REAL-TIME] WebSocket error in payment:', wsError);
      // Jangan gagalkan request hanya karena WebSocket error
    }

    // JIKA ORDER SUDAH SELESAI, BERI POIN
    if (order.status === 'done' && order.user_id) {
      console.log(`🎯 [PAYMENT] Triggering points award for order ${id}`);
      addPointsAfterOrderCompletion(order.id);
    } else {
      console.log(`⏩ [PAYMENT] Skipping points award - Conditions:`, {
        status_done: order.status === 'done',
        has_user: !!order.user_id,
      });
    }

    return res.json({
      success: true,
      message: 'Payment confirmed successfully',
      data: {
        order: order.toJSON(),
        payment: payment ? payment.toJSON() : null,
      },
    });
  } catch (error) {
    await transaction.rollback();
    console.error('❌ [PAYMENT] Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to confirm payment',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined,
    });
  }
};

// GET REPORT - WITH COUPON STATS
const getReport = async (req, res) => {
  try {
    const { from, to, payment_type } = req.query;

    const where = {
      status: 'done',
      is_paid: true,
    };

    if (from && to) {
      where.createdAt = {
        [Op.between]: [new Date(from), new Date(to)],
      };
    }

    if (payment_type) {
      where.payment_type = payment_type;
    }

    const orders = await Order.findAll({
      where,
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name'],
          required: false,
        },
        {
          model: Table,
          as: 'table',
          attributes: ['table_number'],
          required: false,
        },
      ],
    });

    const total_income = orders.reduce((acc, o) => acc + o.total_price, 0);
    const total_discount = orders.reduce(
      (acc, o) => acc + (o.discount_amount || 0),
      0
    );
    const total_orders_with_coupon = orders.filter(
      (o) => o.discount_amount > 0
    ).length;
    const total_points_given = orders.reduce(
      (acc, o) => acc + (o.points_earned || 0),
      0
    );

    res.json({
      total_order: orders.length,
      total_income,
      total_discount,
      total_orders_with_coupon,
      total_points_given,
      average_discount:
        total_orders_with_coupon > 0
          ? Math.round(total_discount / total_orders_with_coupon)
          : 0,
      orders,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      message: 'Gagal mengambil laporan',
    });
  }
};

// GET USER ORDER HISTORY - WITH POINTS SUMMARY
const getUserOrderHistory = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const { count, rows: orders } = await Order.findAndCountAll({
      where: { user_id: req.user.id },
      include: [
        {
          model: OrderItem,
          as: 'items',
          include: {
            model: Menu,
            attributes: ['name', 'price'],
          },
        },
        {
          model: Table,
          as: 'table',
          attributes: ['table_number'],
          required: false,
        },
      ],
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    // Hitung total poin dan stats
    const completedOrders = await Order.findAll({
      where: {
        user_id: req.user.id,
        status: 'done',
        is_paid: true,
      },
      attributes: ['total_price', 'points_earned', 'discount_amount'],
    });

    const total_points_earned = completedOrders.reduce((sum, order) => {
      return sum + (order.points_earned || 0);
    }, 0);

    const total_savings = completedOrders.reduce((sum, order) => {
      return sum + (order.discount_amount || 0);
    }, 0);

    res.status(200).json({
      success: true,
      message: 'Berhasil mengambil riwayat pesanan',
      data: {
        orders: orders,
        points_summary: {
          total_points_earned: total_points_earned,
          total_orders: completedOrders.length,
          total_spent: completedOrders.reduce(
            (sum, order) => sum + order.total_price,
            0
          ),
          total_savings: total_savings,
          current_points: req.user.points, // From auth middleware
        },
      },
      pagination: {
        total: count,
        page: parseInt(page),
        limit: parseInt(limit),
      },
    });
  } catch (err) {
    console.error('Get user orders error:', err);
    res.status(500).json({
      success: false,
      message: 'Gagal mengambil riwayat pesanan',
    });
  }
};

// VALIDATE COUPON FOR ORDER
const validateCouponForOrder = async (req, res) => {
  try {
    const { user_coupon_id, total_amount } = req.body;

    if (!user_coupon_id || !req.user?.id) {
      return res.status(400).json({
        success: false,
        message: 'User coupon ID dan user ID diperlukan',
      });
    }

    const userCoupon = await UserCoupon.findOne({
      where: {
        id: user_coupon_id,
        user_id: req.user.id,
        is_used: false,
      },
      include: [
        {
          model: Coupon,
          as: 'coupon',
          where: {
            is_active: true,
            [Op.or]: [
              { valid_until: null },
              { valid_until: { [Op.gt]: new Date() } },
            ],
          },
        },
      ],
    });

    if (!userCoupon || !userCoupon.coupon) {
      return res.status(404).json({
        success: false,
        message: 'Kupon tidak valid atau sudah digunakan',
      });
    }

    const coupon = userCoupon.coupon;
    let discount_amount = 0;

    if (coupon.discount_type === 'percentage') {
      discount_amount = Math.floor(
        total_amount * (coupon.discount_value / 100)
      );
    } else if (coupon.discount_type === 'fixed') {
      discount_amount = Math.min(coupon.discount_value, total_amount);
    }

    const final_price = Math.max(0, total_amount - discount_amount);

    res.json({
      success: true,
      data: {
        valid: true,
        coupon: {
          name: coupon.name,
          discount_type: coupon.discount_type,
          discount_value: coupon.discount_value,
          discount_amount: discount_amount,
          final_price: final_price,
        },
      },
    });
  } catch (error) {
    console.error('Validate coupon error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal validasi kupon',
      error: process.env.NODE_ENV === 'development' ? error.message : null,
    });
  }
};

module.exports = {
  validateTableNumber, 
  createOrder,
  createOrderGuest,
  getAllOrders,
  getOrderById,
  getPublicOrderById,
  updateOrderStatus,
  confirmCashPayment,
  getReport,
  getUserOrderHistory,
  validateCouponForOrder,
};
